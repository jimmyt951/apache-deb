var searchData=
[
  ['platform_20definitions_2160',['Platform Definitions',['../group__apr__platform.html',1,'']]],
  ['poll_20routines_2161',['Poll Routines',['../group__apr__poll.html',1,'']]],
  ['portability_20routines_2162',['Portability Routines',['../group__apr__portabile.html',1,'']]],
  ['process_20locking_20routines_2163',['Process Locking Routines',['../group__apr__proc__mutex.html',1,'']]],
  ['pollset_20flags_2164',['Pollset Flags',['../group__pollflags.html',1,'']]],
  ['poll_20options_2165',['Poll options',['../group__pollopts.html',1,'']]],
  ['pool_20cleanup_20functions_2166',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['pool_20debugging_20functions_2e_2167',['Pool Debugging functions.',['../group___pool_debug.html',1,'']]]
];
