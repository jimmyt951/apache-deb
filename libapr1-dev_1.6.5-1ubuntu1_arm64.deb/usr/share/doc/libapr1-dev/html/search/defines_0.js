var searchData=
[
  ['apr_5fdeclare_5finherit_5fset_2109',['APR_DECLARE_INHERIT_SET',['../apr__inherit_8h.html#aa67d345784df8cce8114086e1f67cf3d',1,'apr_inherit.h']]],
  ['apr_5fdeclare_5finherit_5funset_2110',['APR_DECLARE_INHERIT_UNSET',['../apr__inherit_8h.html#ad4886be514d6cead6bd119a48984d4b5',1,'apr_inherit.h']]],
  ['apr_5fis_5fdev_5fstring_2111',['APR_IS_DEV_STRING',['../apr__version_8h.html#aa07a7cfd506f536ca2e097d924ffcec8',1,'apr_version.h']]],
  ['apr_5fmajor_5fversion_2112',['APR_MAJOR_VERSION',['../apr__version_8h.html#a09ffaed0dcb07c22aa5a0efbc41043c2',1,'apr_version.h']]],
  ['apr_5fminor_5fversion_2113',['APR_MINOR_VERSION',['../apr__version_8h.html#a9470ed7888fcc5637eaf0291a324fcde',1,'apr_version.h']]],
  ['apr_5fpatch_5fversion_2114',['APR_PATCH_VERSION',['../apr__version_8h.html#a8c8c1cbf8000059090ba4ac4365eda7d',1,'apr_version.h']]],
  ['apr_5fstringify_2115',['APR_STRINGIFY',['../apr__version_8h.html#ae90215615972dfa4108018304361ef0b',1,'apr_version.h']]],
  ['apr_5fstringify_5fhelper_2116',['APR_STRINGIFY_HELPER',['../apr__version_8h.html#a71918dd8c53e093283b43b0ff0965439',1,'apr_version.h']]],
  ['apr_5fversion_5fat_5fleast_2117',['APR_VERSION_AT_LEAST',['../apr__version_8h.html#ac0646746397b0cb17a6d88ce55558fed',1,'apr_version.h']]],
  ['apr_5fversion_5fstring_2118',['APR_VERSION_STRING',['../apr__version_8h.html#ac420a8c4636151e4086a18673a3335e7',1,'apr_version.h']]],
  ['apr_5fversion_5fstring_5fcsv_2119',['APR_VERSION_STRING_CSV',['../apr__version_8h.html#ac49895cc329e2b507f72a7afc62a25c6',1,'apr_version.h']]],
  ['apr_5fwant_5fiovec_2120',['APR_WANT_IOVEC',['../apr__file__io_8h.html#a79e8fc75167d0e530c6afb5172e2a32b',1,'apr_file_io.h']]],
  ['apr_5fwant_5fmemfunc_2121',['APR_WANT_MEMFUNC',['../apr__allocator_8h.html#a26faf43e3f61783d8b7aa928c0a41a11',1,'APR_WANT_MEMFUNC():&#160;apr_allocator.h'],['../apr__pools_8h.html#a26faf43e3f61783d8b7aa928c0a41a11',1,'APR_WANT_MEMFUNC():&#160;apr_pools.h']]],
  ['apr_5fwant_5fstdio_2122',['APR_WANT_STDIO',['../apr__file__io_8h.html#a4f3ace9204c571a34c0b2b9bd23b1133',1,'apr_file_io.h']]]
];
