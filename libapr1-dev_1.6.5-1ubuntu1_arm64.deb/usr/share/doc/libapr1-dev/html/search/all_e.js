var searchData=
[
  ['platform_20definitions_1236',['Platform Definitions',['../group__apr__platform.html',1,'']]],
  ['poll_20routines_1237',['Poll Routines',['../group__apr__poll.html',1,'']]],
  ['portability_20routines_1238',['Portability Routines',['../group__apr__portabile.html',1,'']]],
  ['process_20locking_20routines_1239',['Process Locking Routines',['../group__apr__proc__mutex.html',1,'']]],
  ['p_1240',['p',['../structapr__pollfd__t.html#adae68586ed671472590efe8770de38cc',1,'apr_pollfd_t']]],
  ['patch_1241',['patch',['../structapr__version__t.html#a98a629a88e776642d6e527d7535e0791',1,'apr_version_t']]],
  ['pid_1242',['pid',['../structapr__proc__t.html#a8a8ee4b234156485a72497023e7482e5',1,'apr_proc_t']]],
  ['place_1243',['place',['../structapr__getopt__t.html#a87961387d1c71bebfbdf69c7f392d2d5',1,'apr_getopt_t']]],
  ['pollset_20flags_1244',['Pollset Flags',['../group__pollflags.html',1,'']]],
  ['poll_20options_1245',['Poll options',['../group__pollopts.html',1,'']]],
  ['pool_1246',['pool',['../structapr__finfo__t.html#a71496f86b5489c87e58e9c03fe468fb8',1,'apr_finfo_t::pool()'],['../structapr__sockaddr__t.html#a5f2d72a6a181cf2f54ba7c922aa0dfab',1,'apr_sockaddr_t::pool()'],['../structapr__array__header__t.html#a68f353ce65943172fcc9494aa9f6e424',1,'apr_array_header_t::pool()']]],
  ['pool_20cleanup_20functions_1247',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['pool_20debugging_20functions_2e_1248',['Pool Debugging functions.',['../group___pool_debug.html',1,'']]],
  ['port_1249',['port',['../structapr__sockaddr__t.html#a174c19138de9c208f13ed71b5892e505',1,'apr_sockaddr_t']]],
  ['protection_1250',['protection',['../structapr__finfo__t.html#a7c09d73ad1957e2c0e6c6b77d94e90ab',1,'apr_finfo_t']]],
  ['protocol_1251',['protocol',['../structapr__os__sock__info__t.html#a176ede3ecf40abf0f82a01bfeb95f1e3',1,'apr_os_sock_info_t']]]
];
