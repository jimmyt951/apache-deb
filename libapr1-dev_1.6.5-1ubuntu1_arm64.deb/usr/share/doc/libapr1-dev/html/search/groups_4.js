var searchData=
[
  ['functions_20for_20manipulating_20the_20environment_2136',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]],
  ['file_20attribute_20flags_2137',['File Attribute Flags',['../group__apr__file__attrs__set__flags.html',1,'']]],
  ['file_20information_2138',['File Information',['../group__apr__file__info.html',1,'']]],
  ['file_20i_2fo_20handling_20functions_2139',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['file_20lock_20types_2140',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]],
  ['file_20open_20flags_2froutines_2141',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['file_20permissions_20flags_2142',['File Permissions flags',['../group__apr__file__permissions.html',1,'']]],
  ['file_20seek_20flags_2143',['File Seek Flags',['../group__apr__file__seek__flags.html',1,'']]],
  ['filepath_20manipulation_20functions_2144',['Filepath Manipulation Functions',['../group__apr__filepath.html',1,'']]],
  ['filename_20matching_20functions_2145',['Filename Matching Functions',['../group__apr__fnmatch.html',1,'']]]
];
