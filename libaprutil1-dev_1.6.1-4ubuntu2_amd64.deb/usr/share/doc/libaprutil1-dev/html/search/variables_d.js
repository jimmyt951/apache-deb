var searchData=
[
  ['open_1231',['open',['../structapr__dbd__driver__t.html#a5ff28470f647176e6ea26e8207ab02dd',1,'apr_dbd_driver_t::open()'],['../structapr__dbm__type__t.html#a823966386777dcdc76081cccb7c493e1',1,'apr_dbm_type_t::open()']]]
];
