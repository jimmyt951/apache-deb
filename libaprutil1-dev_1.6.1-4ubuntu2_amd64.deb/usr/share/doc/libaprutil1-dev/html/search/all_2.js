var searchData=
[
  ['crypto_20routines_588',['Crypto routines',['../group___a_p_r___util___crypto.html',1,'']]],
  ['can_5fmmap_589',['can_mmap',['../structapr__bucket__file.html#a7812a8d6e6f10d0095569f04d3423e83',1,'apr_bucket_file']]],
  ['check_5fconn_590',['check_conn',['../structapr__dbd__driver__t.html#a644f9d26c9a3f3ebbde35fcc5caa7903',1,'apr_dbd_driver_t']]],
  ['close_591',['close',['../structapr__dbd__driver__t.html#a51f2fb88a8f6d109e859e470c12922e2',1,'apr_dbd_driver_t::close()'],['../structapr__dbm__type__t.html#ad279fc2ecb08cb1c8b4dc93feacb8491',1,'apr_dbm_type_t::close()']]],
  ['cluster_5fenabled_592',['cluster_enabled',['../structapr__redis__stats__t.html#a2522a2f0ce40a9a35015d8affe49498f',1,'apr_redis_stats_t']]],
  ['cmd_5fget_593',['cmd_get',['../structapr__memcache__stats__t.html#abd9b0fa7bf554436883c8b6a2a89c2a8',1,'apr_memcache_stats_t']]],
  ['cmd_5fset_594',['cmd_set',['../structapr__memcache__stats__t.html#a4930557b41d879b1b4767862c1693f95',1,'apr_memcache_stats_t']]],
  ['compare_595',['compare',['../structapr__strmatch__pattern.html#aded054f3d6701a163816e3ed7f257242',1,'apr_strmatch_pattern']]],
  ['connected_5fclients_596',['connected_clients',['../structapr__redis__stats__t.html#a662da35ea55c251ba6b669314d7bb452',1,'apr_redis_stats_t']]],
  ['connected_5fslaves_597',['connected_slaves',['../structapr__redis__stats__t.html#a8727a6f8fa7b6e7464aa50d422ea672d',1,'apr_redis_stats_t']]],
  ['connection_5fstructures_598',['connection_structures',['../structapr__memcache__stats__t.html#ac155c7a510e94b3cd43aea90a05e3cd3',1,'apr_memcache_stats_t']]],
  ['conns_599',['conns',['../structapr__memcache__server__t.html#a49f27525b9dd7de3dfb15dba3b86bd05',1,'apr_memcache_server_t::conns()'],['../structapr__redis__server__t.html#a0ef6a659b5490d8c0859edc7c86c1f13',1,'apr_redis_server_t::conns()']]],
  ['context_600',['context',['../structapr__strmatch__pattern.html#a0e74c401e8825e462e202175bf033a9c',1,'apr_strmatch_pattern']]],
  ['copy_601',['copy',['../structapr__bucket__type__t.html#a4e64635ed62e1f371154f934c8a8504f',1,'apr_bucket_type_t']]],
  ['count_602',['count',['../structapr__md4__ctx__t.html#a0332072316c6a931b6fb1bd8729e3495',1,'apr_md4_ctx_t::count()'],['../structapr__md5__ctx__t.html#a3234a76e68a4ef546026a9854f9ba6d0',1,'apr_md5_ctx_t::count()']]],
  ['count_5flo_603',['count_lo',['../structapr__sha1__ctx__t.html#ab105efa48b9318a419525e0f6076f6d2',1,'apr_sha1_ctx_t']]],
  ['curr_5fconnections_604',['curr_connections',['../structapr__memcache__stats__t.html#a1db1876674d978f4f70ae465a060bfc2',1,'apr_memcache_stats_t']]],
  ['curr_5fitems_605',['curr_items',['../structapr__memcache__stats__t.html#abe0f28297441a55d30a6c7c8e0faaea3',1,'apr_memcache_stats_t']]]
];
