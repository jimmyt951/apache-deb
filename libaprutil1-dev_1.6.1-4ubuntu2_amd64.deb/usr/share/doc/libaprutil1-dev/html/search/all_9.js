var searchData=
[
  ['keyspace_5fhits_657',['keyspace_hits',['../structapr__redis__stats__t.html#a48afcd24a53bab228576c4e649e989db',1,'apr_redis_stats_t']]],
  ['keyspace_5fmisses_658',['keyspace_misses',['../structapr__redis__stats__t.html#ab0928f7503120f1a1db21ec001c8c4ed',1,'apr_redis_stats_t']]]
];
